package com.example.ricelimepredictionapp.model

import com.google.gson.annotations.SerializedName

data class ResponseRegister(

	@field:SerializedName("msg")
	val msg: String? = null
)
